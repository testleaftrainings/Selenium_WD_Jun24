package pages;

import base.ProjectSpecificMethod;

public class WelcomePage extends ProjectSpecificMethod{

	public HomePage clickCrmsfa() {
		
		return new HomePage();
	}
	
	public LoginPage clickLogout() {
	
		return new LoginPage();
	}
	
	
}
