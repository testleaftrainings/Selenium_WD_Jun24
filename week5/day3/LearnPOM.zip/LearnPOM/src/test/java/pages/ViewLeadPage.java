package pages;

import base.ProjectSpecificMethod;

public class ViewLeadPage extends ProjectSpecificMethod{

	public ViewLeadPage getLeadId() {
		
		return this;
	}
	
	
	
}
