package pages;

import base.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod{

	public CreateLeadPage clickCreateLeadLink() {
		
		return new CreateLeadPage();
	}
	
	public void clickFindLeadLink() {
		
	}
	
	
}
