package pages;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod{

	public CreateLeadPage enterCompanyName() {
	
		
		return this;
	}
	
	public CreateLeadPage enterFirstName() {
	
		return this;
	}
	
	public CreateLeadPage enterLastName() {
		
		return this;
	}
	
	public ViewLeadPage clickCreateLeadBtn() {
		
		return new ViewLeadPage();
	}
	
	
	
}
