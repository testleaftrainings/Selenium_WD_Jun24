package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class EditLeadPage extends ProjectSpecificMethod{

	
	public EditLeadPage(ChromeDriver driver) {
		this.driver = driver;
	}


	public EditLeadPage updateCompanyName(String cname) {
		WebElement cnameField = driver.findElement(By.id("updateLeadForm_companyName"));
		cnameField.clear();
		cnameField.sendKeys(cname);
		return this;
	}
	
	
	public ViewLeadPage clickUpdateBtn() {
		driver.findElement(By.className("smallSubmit")).click();
		return new ViewLeadPage(driver);
	}
	
}
