package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class WelcomePage extends ProjectSpecificMethod{

	public WelcomePage(ChromeDriver driver) {
		this.driver =driver;
	}

	public HomePage clickCrmsfa() {
		driver.findElement(By.partialLinkText("CRM")).click();
		return new HomePage(driver);
	}
	
	public LoginPage clickLogout() {
	
		return new LoginPage(driver);
	}
	
	
}
