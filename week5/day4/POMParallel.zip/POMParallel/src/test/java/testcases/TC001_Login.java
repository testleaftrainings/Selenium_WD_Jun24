package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC001_Login extends ProjectSpecificMethod{

	
	@Test(dataProvider = "getData")
	public void runLogin(String username, String password) {
		System.out.println("driver in @Test "+driver);
		LoginPage lp = new LoginPage(driver);		
		lp
		.enterUsername(username)
		.enterPassword(password)
		.clickLogin();
	}
	
	
	@BeforeTest
	public void setData() {
		fileName = "Login";
	}
	
	
}
