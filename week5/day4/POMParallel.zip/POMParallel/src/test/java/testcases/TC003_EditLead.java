package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC003_EditLead extends ProjectSpecificMethod {

	@Test(dataProvider = "getData")
	public void runEditLead(String username, String password, String phno, String cname) throws InterruptedException {
		
		new LoginPage(driver)
		.enterUsername(username)
		.enterPassword(password)
		.clickLogin()
		.clickCrmsfa()
		.clickLeadsTab()
		.clickFindLeadLink()
		.clickPhoneTab()
		.enterPhno(phno)
		.clickFindLeadsBtn()
		.clickFirstLeadId()
		.clickEditLink()
		.updateCompanyName(cname)
		.clickUpdateBtn()
		.getLeadId();
		
	}
	
	@BeforeTest
	public void setData() {
		fileName = "EditLead";
	}
}
