package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC002_CreateLead extends ProjectSpecificMethod{

	
	@Test(dataProvider = "getData")
	public void runCreateLead(String username, String password, String cname, String fname, String lname) {
		
		new LoginPage(driver)
		.enterUsername(username)
		.enterPassword(password)
		.clickLogin()
		.clickCrmsfa()
		.clickLeadsTab()
		.clickCreateLeadLink()
		.enterCompanyName(cname)
		.enterLastName(lname)
		.enterFirstName(fname)
		.clickCreateLeadBtn()
		.getLeadId();
		
		
	}
	
	@BeforeTest
	public void setData() {
		fileName = "CreateLead";
	}
	
}
