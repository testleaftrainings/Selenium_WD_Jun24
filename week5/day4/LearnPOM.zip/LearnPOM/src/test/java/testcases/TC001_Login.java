package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC001_Login extends ProjectSpecificMethod{

	
	@Test(dataProvider = "getData")
	public void runLogin(String username, String password) {
		
		LoginPage lp = new LoginPage();		
		lp
		.enterUsername(username)
		.enterPassword(password)
		.clickLogin();
	}
	
	
	@BeforeTest
	public void setData() {
		fileName = "Login";
	}
	
	
}
