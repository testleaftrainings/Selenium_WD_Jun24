package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod{

	public LoginPage enterUsername(String uname) {
		
		driver.findElement(By.id("username")).sendKeys(uname);
		
//		LoginPage lp = new LoginPage();
//		return lp;
		
//		return new LoginPage();
		
		return this;
	}
	
	
	public LoginPage enterPassword(String pwd) {
		
		driver.findElement(By.id("password")).sendKeys(pwd);
		return this;
	}
	
	
	public WelcomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		
		return new WelcomePage();
	}
	
}
