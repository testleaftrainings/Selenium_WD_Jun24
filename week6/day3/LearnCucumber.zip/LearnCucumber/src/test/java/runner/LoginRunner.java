package runner;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/test/java/features", glue ="stepDef")
public class LoginRunner extends ProjectSpecificMethod {

}
