package stepDef;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;

public class Login extends ProjectSpecificMethod{

	public Login(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public Login() {
		
	}
	
	@Given("Enter username")
	public void enterUsername() {
		
		driver.findElement(By.id("username")).sendKeys("democsr");
		
	}
	
	@Given ("Enter password")
	public void enterPassword() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
	}
	
}
