package runner;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;


public class TC002_CreateLead extends ProjectSpecificMethod{

	
	@Test
	public void runCreateLead() throws IOException {
		
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeadsTab()
		.clickCreateLeadLink()
		.enterCompanyName("TestLeaf")
		.enterFirstName("Gokul")
		.enterLastName("Sekar")
		.clickCreateLeadBtn();
	}
	
		
	@BeforeTest
	public void setData() {
		testcaseName ="TC002_Create Lead";
		testcaseDesc = "Create Lead testcase with valid credentials";
		authorName = "Gokul";
		categoryName = "Regression";
	}
	
}
