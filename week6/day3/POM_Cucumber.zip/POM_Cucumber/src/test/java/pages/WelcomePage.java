package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends ProjectSpecificMethod{
	
	@Then ("Verify the login is successful")
	public void verifyLogin() {
		System.out.println(getDriver().getTitle());
	}
	
	@When ("Click on crmsfa link")
	public HomePage clickCrmsfa() throws IOException {
		try {
			getDriver().findElement(By.partialLinkText("CRM")).click();
			reportStep("pass", "Crmsfa link clicked successfully");
		} catch (Exception e) {
			reportStep("fail", "unable to click crmsfa link");
		}
		return new HomePage();
	}
	
	public LoginPage clickLogout() {
	
		return new LoginPage();
	}
	
	
}
