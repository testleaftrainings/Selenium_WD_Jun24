package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class LeadsPage extends ProjectSpecificMethod{

	@When ("Click on create lead link")
	public CreateLeadPage clickCreateLeadLink() throws IOException {
		try {
			getDriver().findElement(By.linkText("Create Lead")).click();
			reportStep("pass", "Create Lead link clicked successfully");
		} catch (Exception e) {
			reportStep("fail", "Unable to click Create Lead Link");
		}
		return new CreateLeadPage();
	}
	
	public FindLeadsPage clickFindLeadLink() {
		getDriver().findElement(By.linkText("Find Leads")).click();
		return new FindLeadsPage();
	}
	
	
}
