package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class ViewLeadPage extends ProjectSpecificMethod{

	public ViewLeadPage getLeadId() {
		String leadId = getDriver().findElement(By.id("viewLead_companyName_sp")).getText().replaceAll("[^0-9]", "");
		System.out.println(leadId);
		return this;
	}
	
	public EditLeadPage clickEditLink() {
		getDriver().findElement(By.linkText("Edit")).click();
		return new EditLeadPage();
	}
	
	
	
}
