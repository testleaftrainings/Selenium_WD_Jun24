package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class HomePage extends ProjectSpecificMethod{

	@When ("Click on Leads tab")
	public LeadsPage clickLeadsTab() throws IOException {
		try {
			getDriver().findElement(By.linkText("Leads")).click();
			reportStep("pass", "Leads tab clicked successfully");
		} catch (Exception e) {
			reportStep("fail", "Unable to click Leads tab");
		}
		return new LeadsPage();
	}
	
	public void clickAccountsTab() {
		
	}
	
	
	public void clickContactsTab() {
		
	}
	
	
}
