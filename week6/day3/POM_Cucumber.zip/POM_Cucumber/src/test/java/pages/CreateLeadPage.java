package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CreateLeadPage extends ProjectSpecificMethod{
	@Given ("Enter the company name as (.*)$")
	public CreateLeadPage enterCompanyName(String cname) throws IOException {
		try {
			getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
			reportStep("pass", "Companyname "+cname+" is  entered successfully");
		} catch (Exception e) {
			reportStep("fail", "Unable enter the company name");
		}
		
		return this;
	}
	
	@Given ("Enter the first name as (.*)$")
	public CreateLeadPage enterFirstName(String fname) throws IOException {
		try {
			getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
			reportStep("pass", "First name "+ fname+" is enter successfully");
		} catch (Exception e) {
			reportStep("fail", "unable to enter first name");
		}
		return this;
	}
	
	@Given("Enter the last name as (.*)$")
	public CreateLeadPage enterLastName(String lname) throws IOException {
		try {
			getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
			reportStep("pass", "Last name "+lname+" is enter successfully");
		} catch (Exception e) {
			reportStep("fail", "Unable to enter the last name");
		}
		return this;
	}
	
	@When ("Click on create Lead button")
	public ViewLeadPage clickCreateLeadBtn() throws IOException {
		try {
			getDriver().findElement(By.name("submitButton")).click();
			reportStep("pass", "Create button clicked successfully");
		} catch (Exception e) {
			reportStep("fail", "Unable to click on the Create lead button");
		}
		return new ViewLeadPage();
	}
	
	
	
}
