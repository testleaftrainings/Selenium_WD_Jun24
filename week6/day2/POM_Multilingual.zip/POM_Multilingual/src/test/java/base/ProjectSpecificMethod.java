package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;




public class ProjectSpecificMethod {

	public static ChromeDriver driver;
	public String fileName;
	public static Properties prop;
	
	@Parameters({"fileName"})
	@BeforeMethod
	public void preCondition(String fName) throws IOException {
		//Step1 : Create object for FileInputStream and pass properties file in the constructor
		FileInputStream fis = new FileInputStream("./src/test/resources/"+fName+".properties");
		
		//Step2 : Create object for Properties class from java.util package
		prop = new Properties();
		
		//Step3 : Load the properties file
		prop.load(fis);
				
		driver = new ChromeDriver();
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	
	@AfterMethod
	public void postCondition() {
		driver.close();
	}
	
	
}
