package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import base.ProjectSpecificMethod;

public class WelcomePage extends ProjectSpecificMethod{

	public WelcomePage clickHambugerBtn() {
		driver.findElement(By.xpath("//div[@class='burger-lottie']")).click();
		return this;
	}
	
	public WelcomePage clickProduct() {
		
		WebElement productWE = driver.findElement(By.xpath("(//div[text()='"+prop.getProperty("product")+"'])[1]"));
		new Actions(driver).moveToElement(productWE).perform();
		driver.executeScript("arguments[0].click()", productWE);
		return this;
	}
	
	public WelcomePage clickTransalationQuality() throws InterruptedException {
		Thread.sleep(3000);
		WebElement qualityWE = driver.findElement(By.xpath("//div[contains(text(),'"+prop.getProperty("TranslationQuality")+"')]"));
		try {
			qualityWE.click();
		} catch (Exception e) {
			driver.executeScript("arguments[0].click()", qualityWE);
		}
		return this;
	}
}
