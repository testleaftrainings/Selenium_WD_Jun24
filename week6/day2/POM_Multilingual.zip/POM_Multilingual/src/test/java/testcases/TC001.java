package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.WelcomePage;

public class TC001 extends ProjectSpecificMethod {

	@Test
	public void runTc001() throws InterruptedException {
		new WelcomePage()
		
		.clickProduct()
		.clickTransalationQuality();
	}
	
}
