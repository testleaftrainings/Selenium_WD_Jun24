package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class WelcomePage extends ProjectSpecificMethod{

	public HomePage clickCrmsfa() {
		driver.findElement(By.partialLinkText("CRM")).click();
		return new HomePage();
	}
	
	public LoginPage clickLogout() {
	
		return new LoginPage();
	}
	
	
}
