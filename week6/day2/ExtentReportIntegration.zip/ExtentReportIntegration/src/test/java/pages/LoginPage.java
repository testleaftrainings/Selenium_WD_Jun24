package pages;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;

import com.aventstack.extentreports.MediaEntityBuilder;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod{

	public LoginPage enterUsername() throws IOException {
		System.out.println(prop.getProperty("username"));
		try {
			driver.findElement(By.id("username")).sendKeys(prop.getProperty("username"));
//			int random = (int) ((Math.random())*99999);
//			File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
//			File desc = new File("./snaps/img"+random+".png");
//			FileUtils.copyFile(screenshotAs, desc);
//			test.pass("Username enter successfully", MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+random+".png").build());
			reportStep("pass", "username entered successfully");
		} catch (Exception e) {
//			int random = (int) ((Math.random())*99999);
//			File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
//			File desc = new File("./snaps/img"+random+".png");
//			FileUtils.copyFile(screenshotAs, desc);
//			test.fail("Unable to enter the username "+e, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+random+".png").build());
			reportStep("fail", "Unable to enter the password "+e);
		}
		
//		LoginPage lp = new LoginPage();
//		return lp;
		
//		return new LoginPage();
		
		return this;
	}
	
	
	public LoginPage enterPassword() throws IOException {
		
		try {
			driver.findElement(By.id("password")).sendKeys(prop.getProperty("password"));
//			int random = (int) ((Math.random())*99999);
//			File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
//			File desc = new File("./snaps/img"+random+".png");
//			FileUtils.copyFile(screenshotAs, desc);
//			test.pass("password enter successfully", MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
			reportStep("pass", "password enter successfully");
			
		} catch (Exception e) {
//			int random = (int) ((Math.random())*99999);
//			File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
//			File desc = new File("./snaps/img"+random+".png");
//			FileUtils.copyFile(screenshotAs, desc);
//			test.fail("Unable to enter the password "+e, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
			reportStep("fail", "Unable to enter the password "+e);
		}
		return this;
	}
	
	
	public WelcomePage clickLogin() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("pass", "Login button clicked successfully");
		} catch (Exception e) {
			reportStep("fail", "unable to click logi button "+e);
		}
		
		return new WelcomePage();
	}
	
}
