package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC003_EditLead extends ProjectSpecificMethod {

	@Test(dataProvider = "getData")
	public void runEditLead( String phno, String cname) throws InterruptedException, IOException {
		
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickCrmsfa()
		.clickLeadsTab()
		.clickFindLeadLink()
		.clickPhoneTab()
		.enterPhno(phno)
		.clickFindLeadsBtn()
		.clickFirstLeadId()
		.clickEditLink()
		.updateCompanyName(cname)
		.clickUpdateBtn()
		.getLeadId();
		
	}
	
	@BeforeTest
	public void setData() {
		fileName = "EditLead";
	}
}
